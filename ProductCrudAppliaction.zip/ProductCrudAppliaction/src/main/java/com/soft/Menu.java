package com.soft;

import java.util.Scanner;

public class Menu {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome To Product Appliaction");
		
	 	 boolean isvalue=true;
	 	 while(isvalue)
	 	 {
	 		 System.out.println("==========================Menu==========================");
	 		 System.out.println("1: Create New  Products");
	 		 System.out.println("2: Read Products");
	 		 System.out.println("3: Delete Products");
	 		 System.out.println("4: Update Products");
	 		 System.out.println("5: Exit");
	 		 
	 		 System.out.print("Enter Choice=");
	 		 int choice=sc.nextInt();
	 		 
	 		 switch(choice)
	 		 {
	 		 
	 		 case 1: ProductAdd productadd=new ProductAdd();
	 		         productadd.AddProduct();
	 			     break;
	 		 case 2: ProductRead productread=new ProductRead();
	 		         productread.ReadProduct();
	 			   break;
	 		 case 3:ProductDelete productdelete=new ProductDelete();
	 		        productdelete.DeleteProduct();
	 			   break;
	 		 case 4:ProductUpdate productupdate=new ProductUpdate();
	 				productupdate.UpdateProduct();
	 				break;
	 		 case 5:
	 			   System.out.println("Thank You For visting The Product Application");
	 			   isvalue=false;
	 			   break;
	 		 default: System.out.println("Enter Correct Choice");
	 			  
	 			   
	 		 }
	 		 
	 		 
	 		 
	 	 }
		
	}

}
