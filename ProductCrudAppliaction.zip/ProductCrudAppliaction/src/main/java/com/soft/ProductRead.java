package com.soft;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.soft.entity.Product;
import com.soft.sessionconfig.SessionConfig;

public class ProductRead {
	
	public void ReadProduct()
	{
		Session session=SessionConfig.getsession();
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Product Id:=");
		int Id=sc.nextInt();
		
		Product product=session.find(Product.class ,Id);
		System.out.println(product);
		
	}

}
