package com.soft;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.soft.entity.Product;
import com.soft.sessionconfig.SessionConfig;

public class ProductAdd {
	
	public void AddProduct()
	{
		Session session=SessionConfig.getsession();
		Transaction tx=session.beginTransaction();
		
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter The Product Name:=");
		String Name=sc.next();
		System.out.print("Enter The Product Company:=");
		String Comp=sc.next();
		System.out.print("Enter The Product Price:=");
		Float Price=sc.nextFloat();
		
		Product pro=new Product();
		pro.setProName(Name);
		pro.setProComp(Comp);
		pro.setProPrice(Price);
		session.persist(pro);
		tx.commit();
	}

}
