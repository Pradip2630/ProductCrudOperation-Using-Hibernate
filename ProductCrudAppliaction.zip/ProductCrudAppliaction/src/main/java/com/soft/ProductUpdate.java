package com.soft;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.soft.entity.Product;
import com.soft.sessionconfig.SessionConfig;

public class ProductUpdate {
	
	public void UpdateProduct()
	{
		Session session=SessionConfig.getsession();
		Transaction tx=session.beginTransaction();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The Product Id");
		int Id=sc.nextInt();
		
		System.out.print("Enter The Product Name:=");
		String Name=sc.next();
		System.out.print("Enter The Product Company:=");
		String Comp=sc.next();
		System.out.print("Enter The Product Price:=");
		Float Price=sc.nextFloat();
		
		Product product=session.find(Product.class, Id);
		product.setProName(Name);
		product.setProComp(Comp);
		product.setProPrice(Price);
		
		session.merge(product);
		tx.commit();
	}

}
