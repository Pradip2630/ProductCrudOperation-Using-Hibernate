package com.soft.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="product_tab")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int proId;
	private String proName;
	private String proComp;
	private float proPrice;
	public int getProId() {
		return proId;
	}
	public void setProId(int proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProComp() {
		return proComp;
	}
	public void setProComp(String proComp) {
		this.proComp = proComp;
	}
	public float getProPrice() {
		return proPrice;
	}
	
	
	public void setProPrice(float proPrice) {
		this.proPrice = proPrice;
	}
	@Override
	public String toString() {
		return "Product= \n[proId=" + proId + ", \nproName=" + proName + ", \nproComp=" + proComp + ", \nproPrice=" + proPrice
				+ "]";
	}
	
	

}
