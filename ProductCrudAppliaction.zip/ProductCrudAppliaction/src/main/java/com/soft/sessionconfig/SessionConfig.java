package com.soft.sessionconfig;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionConfig {
	
	public static Session getsession()
	{
		Configuration config=new Configuration();
		config.configure("com/soft/cnfg/hibernate.cfg.xml");
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		return session;
	}

}
