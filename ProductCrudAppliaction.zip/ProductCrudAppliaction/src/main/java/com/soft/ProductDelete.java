package com.soft;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.soft.entity.Product;
import com.soft.sessionconfig.SessionConfig;

public class ProductDelete {
	public void DeleteProduct()
	{
		Session session=SessionConfig.getsession();
		Transaction tx=session.beginTransaction();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Product ID");
		int Id=sc.nextInt();
		
		Product product=session.find(Product.class, Id);
	    session.remove(product);
		
	    tx.commit();
	}

}
